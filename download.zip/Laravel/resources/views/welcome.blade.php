@extends('layout')

@section('title')
    My Profile
@endsection

@section('header')
    Charlotte's Project
@endsection
