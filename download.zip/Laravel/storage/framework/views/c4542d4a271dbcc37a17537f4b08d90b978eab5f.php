

<?php $__env->startSection('title'); ?>
    About us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    About page example
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<ul>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> <?php echo e($task); ?> </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>