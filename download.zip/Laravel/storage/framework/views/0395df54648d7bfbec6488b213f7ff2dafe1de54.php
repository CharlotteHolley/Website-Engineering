<?php $__env->startSection('title'); ?>
    My Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    Charlotte's Project
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>