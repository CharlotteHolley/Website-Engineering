<?php

namespace App\Http\Controllers;

use App\deadline;

//use Illuminate\Http\Request;

class deadlineController extends Controller 
{
    public function index() {
        
     $deadlines = deadline::all();
        
        return view('deadlines/index', compact('deadlines'));
    }
    
    public function create() {
        
        return view('deadlines/create');
    }
    
    public function store() {
        
       $attributes = request()->validate([ 
        
        'subject' => ['required', 'min:5', 'max:60'],
        'description' => ['required', 'min:10', 'max:255']
        ]);
        
        Deadline::create($attributes);
        
        return redirect('/deadlines');
        
    }
    
    public function show(Deadline $deadline) {
        
           
        return view('deadlines/show', compact('deadline'));
    
    }
    
    public function edit(Deadline $deadline) {
        
       // $deadline = Deadline::findOrFail($id);
        
        return view('deadlines/edit', compact('deadline'));
    
    }
    
    public function update(Deadline $deadline) {
        
    $deadline->update(request(['subject','description']));
            
    $deadline->save();
    
    return redirect('/deadlines');
    
    }
    
    public function destroy(Deadline $deadline) {
        
        //dd('delete'.$id);
        
       //Deadline::findOrFail($id)->delete();
       
       $deadline->delete();
    
       return redirect('/deadlines');
    
    }

}
