@extends('layout')

@section('title')
    Rooms
@endsection

@section('header')
    Room Availability
@endsection

